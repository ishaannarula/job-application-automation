'GoCardless - Speculative Applications - 5891359 - London'
, 'GoCardless - Senior Credit Analyst - 6600807 - London, UK'
, 'GoCardless - Junior Data Analyst - 6488355 - Riga, Latvia'

, 'PDT Partners - Research Engineer - 5403145 - New York, NY'
, 'PDT Partners - Applied ML Scientist - 1473516 - New York, NY'

, 'Stevens Capital Management - Quantitative Research Analyst - 712340 - Radnor, PA'
, 'Stevens Capital Management - Quantitative Research Analyst - 4833309 - Jersey City, NJ - Jersey City, NJ'
, 'Stevens Capital Management - Quantitative Research Analyst - 3891358 - Remote - Radnor, PA'
, 'Stevens Capital Management - Quantitative Research Developer - 1659323 - Radnor, PA'
, 'Stevens Capital Management - Quantitative Research Developer - 4833303 - Jersey City, NJ - Jersey City, NJ'
, 'Stevens Capital Management - Quantitative Research Developer - 4262414 - Remote - Radnor, PA'

, 'T. Rowe Price - Fixed Income – Quantitative Investment Analyst – Portfolio Construction - 75030 - London, Warwick Court'
, 'T. Rowe Price - Fixed Income – Quantitative Investment Analyst – Portfolio Construction - 75237 - New York, NY '
, 'T. Rowe Price - Fixed Income – Quantitative Investment Analyst – Portfolio Construction - 73767 - Baltimore, MD'
, 'T. Rowe Price - Quantitative Investment Analyst, Equity - 74996 - Baltimore, MD'
, 'T. Rowe Price - Portfolio Analyst- Equity - 74058 - Baltimore, MD'

, 'Soros Fund Management - Quantitative Strategist - 6419028003 - New York'
, 'Soros Fund Management - Quantitative Strategist - 6419026003 - United Kingdom'

, 'Squarepoint Capital - Desk Quant Analyst - 2546549 - London, Madrid, Montreal, Bangalore, Singapore'
, 'Squarepoint Capital - Junior Commodities Fundamental Analyst - 5929246 - Geneva, Houston, London, New York, Paris'
, 'Squarepoint Capital - Junior Quant Researcher - 239376 - London, New York, Singapore, Boston, Paris, Zug, Geneva, Hong Kong, Bangalore'
, 'Squarepoint Capital - Junior Quant Researcher - ML Alpha Research - 6069464 - London, New York, Singapore, Boston, Paris, Zug, Geneva, Hong Kong, Bangalore'
, 'Squarepoint Capital - Quantitative Researcher - Intraday Trading - 6579699 - New York'

, 'Soros Fund Management - Quantitative Strategist - 6419026003 - United Kingdom'
, 'Soros Fund Management - Quantitative Strategist - 6419028003 - New York'

, 'Eclipse Trading - Quantitative Analyst - 7874826002 - Chicago'
, 'Eclipse Trading - Senior Quant Researcher | High Frequency Delta 1 - Expression of Interest - 4209233002 - Hong Kong'
, 'Eclipse Trading - Quantitative Risk Analyst - 7733278002 - Hong Kong'

, 'Chevron - Quantitative Analyst - Option Valuation - R000061119 - London Westferry Circus'

, 'Bridgewater Associates - Associate Portfolio Strategist - 7678420002 - Shanghai, China'
, 'Bridgewater Associates - Investment Engineer - 7844183002 - Westport, CT'
, 'Bridgewater Associates - Portfolio Associate - 7776137002 - Westport, CT'

, 'Shell - Quantitative Analyst - R165673 - London York Road'
, 'Shell - Quant Analyst - R166318 - London - Shell Centre'
, 'Shell - Power Analyst - R161943 - London - Shell Centre'